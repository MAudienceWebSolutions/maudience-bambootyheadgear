<?php // custom template for order status
get_header();
?>
<div id="content">
		<?php framemarket_mp_order_status(); ?>
		<div class="clear"></div>
</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>